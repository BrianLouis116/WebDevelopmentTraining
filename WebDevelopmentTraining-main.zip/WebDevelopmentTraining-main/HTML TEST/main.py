from turtle import Screen, listen, onkeypress
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard

# Set up the screen
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("Snake Game")
scoreboard = Scoreboard()
# Create a Snake object
snake = Snake()

# Create a Food object
food = Food()


# Function to handle keypress events
def up():
    snake.up()


def down():
    snake.down()


def left():
    snake.left()


def right():
    snake.right()


# Listen for keypress events and bind them to functions
listen()
onkeypress(up, "Up")
onkeypress(down, "Down")
onkeypress(left, "Left")
onkeypress(right, "Right")
screen.update()

# Start the game loop
is_game = True
while is_game:
    screen.update()
    time.sleep(0.1)
    snake.move()  # Call the move method of the Snake object
    # Check if the snake has collided with the food
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        scoreboard.increase_score()

    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.xcor() > 280 or snake.head.xcor() < -280:
        is_game = False

    for segment in snake.segments:

        if segment == snake.head:
            pass

        elif snake.head.distance(segment) < 10:
            is_game = False

screen.exitonclick()
