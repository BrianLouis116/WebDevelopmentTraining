from random import *
from turtle import *

screen = Screen()
screen.bgcolor("black")

setup(800, 800)

def colors():
    return random(), random(), random()

hideturtle()
speed("fastest")
tracer(10)
width(2)

for i in range(25):
    for j in range(15):
        pencolor(colors())
        rt(90)
        circle(200-i*2, 90)
        lt(90)
        circle(200-i*2, 90)
        rt(180)
        circle(50, 24)


# Move screen.exitonclick() and done() outside of the inner loop
screen.exitonclick()
done()
